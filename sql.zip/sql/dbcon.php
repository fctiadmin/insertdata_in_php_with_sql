<?php 
$dbcon=mysqli_connect("localhost","root","","student");
?>